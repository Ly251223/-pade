%% PADE APPROXIMATING RATIONAL FORM
% The Pad� approximant often gives better approximation of the function
% than truncating its Taylor series, and it may still work where the Taylor
% series does not converge. For these reasons Pad� approximants are used 
% extensively in computer calculations.
%% PADE FUNCTION
% [P,Q]=PADE(F,Xo,N,M) gives the Pad� approximant to function F about the point X=Xo,
% with numerator order N and denominator order M. The function F must accept X and
% nth as inputs and it must return the value of the nth derivative of F
% calculated at X.
% PADE returns two polynomial forms representing respectively the numerator and the
% denominator of rational approximating form.
%% Example 1

% Define f and its derivatives.
f=@(x,n) cat(2,log(1-x),...                                
                -factorial(n(2:end)-1)./((1-x).^n(2:end)));
            
% Compute Pad� Approximant.
[p,q]=pade(f,0,6,6); 

% Display the results.
x=linspace(0,1,30);
plot(x,log(1-x),...
     x,polyval(p,x)./polyval(q,x),'o');
xlabel('x'); ylabel('Log(1-x)'); legend('Exact','Pad� App.[6/6]') 
%% Example 2

% Define f and its derivatives.
f=@(x,n) cat(2,exp(-x),exp(-x)*((-1).^n(2:end)));
            
% Compute Pad� Approximant.
[p,q]=pade(f,0,2,2); 

% Display the results.
x=linspace(0,1,30);
plot(x,exp(-x),...
     x,polyval(p,x)./polyval(q,x),'o'); 
 xlabel('x'); ylabel('Exp(-x)'); legend('Exact','Pad� App.[2/2]') 